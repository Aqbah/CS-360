package com.example.aqbahinventoryapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Button loginBtn = findViewById(R.id.btnLogin);
        Button signupBtn = findViewById(R.id.btnSignup);

        loginBtn.setOnClickListener(v -> {
            Toast.makeText(this, "Login clicked", Toast.LENGTH_SHORT).show();
        });

        signupBtn.setOnClickListener(v -> {
            Toast.makeText(this, "Signup clicked", Toast.LENGTH_SHORT).show();
        });
    }
}
