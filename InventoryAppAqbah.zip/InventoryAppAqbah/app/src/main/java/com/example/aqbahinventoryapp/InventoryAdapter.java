package com.example.aqbahinventoryapp;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {

    private final List<String> itemList;

    public InventoryAdapter(List<String> items) {
        this.itemList = items;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView itemName, quantity;
        public Button deleteButton;

        public ViewHolder(View itemView) {
            super(itemView);
            itemName = itemView.findViewById(R.id.tvItemName);
            quantity = itemView.findViewById(R.id.tvQuantity);
            deleteButton = itemView.findViewById(R.id.btnDeleteItem);
        }
    }

    @NonNull
    @Override
    public InventoryAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_inventory, parent, false);
        return new ViewHolder(view);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(InventoryAdapter.ViewHolder holder, int position) {
        String item = itemList.get(position);
        holder.itemName.setText(item);
        holder.quantity.setText("Quantity: " + (10 + position)); // Placeholder

        holder.deleteButton.setOnClickListener(v ->
                Toast.makeText(v.getContext(), "Deleted: " + item, Toast.LENGTH_SHORT).show()
        );
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }
}
