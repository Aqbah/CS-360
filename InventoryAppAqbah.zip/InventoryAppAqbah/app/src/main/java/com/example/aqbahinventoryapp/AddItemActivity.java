package com.example.aqbahinventoryapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddItemActivity extends AppCompatActivity {
    EditText etName, etSku, etQty, etThreshold;
    Button btnSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        etName = findViewById(R.id.etItemName);
        etSku = findViewById(R.id.etSKU);
        etQty = findViewById(R.id.etQuantity);
        etThreshold = findViewById(R.id.etThreshold);
        btnSave = findViewById(R.id.btnSaveItem);

        btnSave.setOnClickListener(v -> {
            String name = etName.getText().toString();
            String sku = etSku.getText().toString();
            String qty = etQty.getText().toString();
            String threshold = etThreshold.getText().toString();

            Toast.makeText(this, "Saved: " + name + " (Qty: " + qty + ")", Toast.LENGTH_SHORT).show();
            finish(); // Go back to inventory
        });
    }
}
